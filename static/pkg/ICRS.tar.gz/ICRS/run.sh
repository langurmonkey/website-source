java -Xms128m -Xmx512m -Djava.library.path=./native/linux -jar ICRS.jar

